package com.example.praktyki

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun WysuwaneMenu(onNavigate: (String) -> Unit) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text("Witaj Kuba")
        Button(onClick = { onNavigate("strona_glowna") }) {
            Text("Strona główna")
        }
        Button(onClick = { onNavigate("profil") }) {
            Text("Profil")
        }
        Button(onClick = { /* TODO: Implement wyloguj */ }) {
            Text("Wyloguj")
        }
    }
}
