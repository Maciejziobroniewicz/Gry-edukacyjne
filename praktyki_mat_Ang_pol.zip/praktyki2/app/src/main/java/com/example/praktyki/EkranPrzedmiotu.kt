package com.example.praktyki

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun EkranPrzedmiotu(subject: String, onNavigate: (String) -> Unit) {
    val title = when(subject) {
        "polski" -> "Język polski"
        "matematyka" -> "Matematyka"
        "angielski" -> "Język angielski"
        else -> subject
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 32.dp)
        )

        Button(
            onClick = { onNavigate("klasa/$subject/1-3") }, // Zmiana na nową trasę: klasa/przedmiot/1-3
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .height(60.dp)
        ) {
            Text("Klasy 1-3", fontSize = 18.sp)
        }

        Button(
            onClick = { onNavigate("klasa/$subject/4-6") }, // Zmiana na nową trasę: klasa/przedmiot/4-6
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .height(60.dp)
        ) {
            Text("Klasy 4-6", fontSize = 18.sp)
        }
    }
}
