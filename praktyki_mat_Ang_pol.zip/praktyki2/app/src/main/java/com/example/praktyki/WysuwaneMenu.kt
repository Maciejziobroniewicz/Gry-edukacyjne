package com.example.praktyki

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun WysuwaneMenu(onNavigate: (String) -> Unit) {
    val gradientBrush = Brush.verticalGradient(
        colors = listOf(
            Color(0xFFE3F2FD),
            Color.White
        )
    )

    ModalDrawerSheet(
        modifier = Modifier.fillMaxHeight().width(280.dp), // Nieco węższe menu
        drawerContainerColor = Color.Transparent
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(gradientBrush)
                .padding(20.dp)
        ) {
            // Nagłówek
            Box(
                modifier = Modifier
                    .size(72.dp) // Zmniejszone z 80dp dla lżejszego wyglądu
                    .clip(CircleShape)
                    .background(Color.LightGray),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Home,
                    contentDescription = null,
                    modifier = Modifier.size(36.dp),
                    tint = Color.White
                )
            }

            Text(
                text = "Nie jesteś zalogowany",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 12.dp)
            )
            
            Text(
                text = "Zaloguj się, aby zapisywać postępy",
                fontSize = 13.sp,
                color = Color.Gray,
                modifier = Modifier.padding(top = 4.dp)
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

            MenuItem(
                icon = Icons.Default.Home,
                label = "Strona główna",
                onClick = { onNavigate("strona_glowna") }
            )

            Spacer(modifier = Modifier.weight(1f))

            // Przyciski na dole
            Button(
                onClick = { /* Logowanie */ },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("ZALOGUJ SIĘ", fontSize = 14.sp)
            }

            Spacer(Modifier.height(8.dp))

            OutlinedButton(
                onClick = { /* Rejestracja */ },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("ZAŁÓŻ KONTO", fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun MenuItem(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
        color = Color.Transparent,
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                tint = MaterialTheme.colorScheme.primary,
                contentDescription = null,
                modifier = Modifier.size(24.dp) // Standardowa wielkość ikon (72px)
            )
            Spacer(modifier = Modifier.width(16.dp)) // Optymalny odstęp na tekst
            Text(
                text = label,
                fontSize = 16.sp, // Zmniejszone z 18sp - teraz wejdą nawet długie napisy
                fontWeight = FontWeight.Medium
            )
        }
    }
}
