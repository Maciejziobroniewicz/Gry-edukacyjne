package com.example.praktyki

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun EkranKlasy(subject: String, klasa: String, onNavigate: (String) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val displaySubject = when(subject) {
            "polski" -> "Język polski"
            "angielski" -> "Język angielski"
            "matematyka" -> "Matematyka"
            else -> subject
        }

        Text(
            text = "Klasa $klasa - $displaySubject",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(vertical = 24.dp)
        )

        val kategorie = when(subject) {
            "polski" -> listOf(
                "rz / ż" to "rz_z",
                "h / ch" to "h_ch",
                "u / ó" to "u_o",
                "Mieszane" to "mieszane"
            )
            "angielski" -> listOf(
                "Słówka" to "slowka",
                "Czasowniki nieregularne" to "czasowniki"
            )
            "matematyka" -> if (klasa == "1-3") {
                listOf(
                    "Dodawanie do 10" to "dodawanie_10",
                    "Odejmowanie do 10" to "odejmowanie_10",
                    "Liczby rzymskie do 20" to "rzymskie_20",
                    "Mniej, więcej" to "porownywanie"
                )
            } else {
                listOf(
                    "Dodawanie do 100" to "dodawanie_100",
                    "Odejmowanie do 100" to "odejmowanie_100",
                    "Mnożenie do 100" to "mnozenie_100",
                    "Dzielenie do 100" to "dzielenie_100"
                )
            }
            else -> listOf("Zadania" to "zadania")
        }

        kategorie.forEach { (label, slug) ->
            Button(
                onClick = { 
                    when {
                        subject == "polski" -> onNavigate("wybor_dyktanda/$klasa/$slug")
                        subject == "angielski" && slug == "slowka" -> onNavigate("wybor_slowek/$klasa")
                        subject == "angielski" && slug == "czasowniki" -> onNavigate("zadania/angielski/$klasa/czasowniki_$klasa")
                        subject == "matematyka" -> onNavigate("zadania/matematyka/$klasa/$slug")
                        else -> onNavigate("zadania/$subject/$klasa/$slug")
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .height(64.dp),
                shape = MaterialTheme.shapes.medium
            ) {
                Text(label, fontSize = 20.sp)
            }
        }
    }
}
