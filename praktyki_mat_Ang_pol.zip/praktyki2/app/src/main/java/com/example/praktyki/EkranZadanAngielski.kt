package com.example.praktyki

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun EkranZadanAngielski(categoryId: String) {
    // Sprawdzamy czy to zwykłe słówka czy czasowniki
    val category = allVocabulary.find { it.id == categoryId }
    val verbCategory = if (category == null) allVerbs.find { it.id == categoryId } else null
    
    if (category == null && verbCategory == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Nie znaleziono kategorii.")
        }
        return
    }

    val totalItems = category?.words?.size ?: verbCategory?.verbs?.size ?: 0
    var currentIndex by remember { mutableStateOf(0) }
    
    // Pola dla zwykłych słówek
    var userGuess by remember { mutableStateOf("") }
    
    // Pola dla czasowników
    var infinitiveGuess by remember { mutableStateOf("") }
    var pastSimpleGuess by remember { mutableStateOf("") }
    
    var feedback by remember { mutableStateOf("") }
    var isCorrect by remember { mutableStateOf<Boolean?>(null) }
    var score by remember { mutableStateOf(0) }
    var isFinished by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(scrollState),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (!isFinished) {
            Text(
                text = "Kategoria: ${category?.name ?: verbCategory?.name}",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
            
            Text(
                text = "Zadanie: ${currentIndex + 1} / $totalItems",
                modifier = Modifier.padding(bottom = 32.dp)
            )

            val polishText = category?.words?.get(currentIndex)?.polish ?: verbCategory?.verbs?.get(currentIndex)?.polish ?: ""
            
            Text(text = "Jak jest po angielsku:", fontSize = 18.sp)
            Text(
                text = polishText.uppercase(),
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 16.dp)
            )

            if (category != null) {
                // TRYB SŁÓWEK
                OutlinedTextField(
                    value = userGuess,
                    onValueChange = { userGuess = it },
                    label = { Text("Wpisz po angielsku") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            } else if (verbCategory != null) {
                // TRYB CZASOWNIKÓW (Dwa pola)
                val verb = verbCategory.verbs[currentIndex]
                
                OutlinedTextField(
                    value = infinitiveGuess,
                    onValueChange = { infinitiveGuess = it },
                    label = { Text("Forma podstawowa (np. go)") },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    singleLine = true
                )
                
                OutlinedTextField(
                    value = pastSimpleGuess,
                    onValueChange = { pastSimpleGuess = it },
                    label = { Text("Forma przeszła (np. went)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            if (isCorrect == null) {
                Button(
                    onClick = {
                        if (category != null) {
                            val correct = category.words[currentIndex].english
                            if (userGuess.trim().lowercase() == correct.lowercase()) {
                                isCorrect = true
                                feedback = "Brawo!"
                                score++
                            } else {
                                isCorrect = false
                                feedback = "Błąd. Poprawnie: $correct"
                            }
                        } else if (verbCategory != null) {
                            val v = verbCategory.verbs[currentIndex]
                            val infOk = infinitiveGuess.trim().lowercase() == v.infinitive.lowercase()
                            val pastOk = pastSimpleGuess.trim().lowercase() == v.pastSimple.lowercase()
                            
                            if (infOk && pastOk) {
                                isCorrect = true
                                feedback = "Świetnie! Obie formy poprawne."
                                score++
                            } else {
                                isCorrect = false
                                feedback = "Błąd. Poprawnie: ${v.infinitive} - ${v.pastSimple}"
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp)
                ) {
                    Text("SPRAWDŹ")
                }
            } else {
                Text(
                    text = feedback,
                    color = if (isCorrect == true) Color(0xFF2E7D32) else Color(0xFFC62828),
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                Button(
                    onClick = {
                        if (currentIndex < totalItems - 1) {
                            currentIndex++
                            userGuess = ""
                            infinitiveGuess = ""
                            pastSimpleGuess = ""
                            isCorrect = null
                            feedback = ""
                        } else {
                            isFinished = true
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp)
                ) {
                    Text(if (currentIndex < totalItems - 1) "NASTĘPNE" else "WYNIK")
                }
            }
        } else {
            // EKRAN KOŃCOWY
            Text("KONIEC!", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black)
            Text("Twój wynik:", fontSize = 20.sp, modifier = Modifier.padding(top = 16.dp))
            Text("$score / $totalItems", fontSize = 48.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            
            Spacer(modifier = Modifier.height(32.dp))
            
            Button(
                onClick = {
                    currentIndex = 0
                    userGuess = ""
                    infinitiveGuess = ""
                    pastSimpleGuess = ""
                    isCorrect = null
                    feedback = ""
                    score = 0
                    isFinished = false
                },
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) {
                Text("ZAGRAJ PONOWNIE")
            }
        }
    }
}
