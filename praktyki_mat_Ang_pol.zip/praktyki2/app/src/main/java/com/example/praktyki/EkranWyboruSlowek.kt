package com.example.praktyki

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun EkranWyboruSlowek(klasa: String, onNavigate: (String) -> Unit) {
    val kategorie = if (klasa == "1-3") {
        listOf(
            "Body - Części ciała" to "body",
            "Family - Rodzina" to "family",
            "Food - Jedzenie" to "food",
            "Days - Dni tygodnia" to "days"
        )
    } else {
        listOf(
            "School - Szkoła" to "school",
            "House - Dom" to "home",
            "Animals - Zwierzęta" to "animals",
            "Actions - Czynności" to "actions"
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Kategorie słówek ($klasa)",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(kategorie) { (label, slug) ->
                Card(
                    onClick = { onNavigate("zadania/angielski/$klasa/$slug") },
                    modifier = Modifier.fillMaxWidth(),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .padding(20.dp)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(text = label, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}
