package com.example.praktyki

data class Word(
    val english: String,
    val polish: String
)

data class IrregularVerb(
    val infinitive: String,
    val pastSimple: String,
    val pastParticiple: String,
    val polish: String
)

data class VocabularyCategory(
    val id: String,
    val name: String,
    val words: List<Word>
)

data class VerbCategory(
    val id: String,
    val name: String,
    val verbs: List<IrregularVerb>
)

val allVocabulary = listOf(
    VocabularyCategory(
        id = "body",
        name = "Części ciała",
        words = listOf(
            Word("face", "twarz"),
            Word("ear", "ucho"),
            Word("eye", "oko"),
            Word("hair", "włosy"),
            Word("mouth", "usta"),
            Word("nose", "nos"),
            Word("head", "głowa"),
            Word("arm", "ręka"),
            Word("leg", "noga"),
            Word("foot", "stopa"),
            Word("finger", "palec"),
            Word("hand", "dłoń"),
            Word("toe", "palec u stopy"),
            Word("tooth", "ząb")
        )
    ),
    VocabularyCategory(
        id = "family",
        name = "Rodzina",
        words = listOf(
            Word("mother", "mama"),
            Word("father", "tata"),
            Word("brother", "brat"),
            Word("sister", "siostra"),
            Word("grandmother", "babcia"),
            Word("grandfather", "dziadek"),
            Word("aunt", "ciocia"),
            Word("uncle", "wujek"),
            Word("cousin", "kuzyn / kuzynka"),
            Word("baby", "dziecko / niemowlę")
        )
    ),
    VocabularyCategory(
        id = "food",
        name = "Jedzenie",
        words = listOf(
            Word("bread", "chleb"),
            Word("butter", "masło"),
            Word("cheese", "ser"),
            Word("egg", "jajko"),
            Word("ham", "szynka"),
            Word("jam", "dżem"),
            Word("honey", "miód"),
            Word("yoghurt", "jogurt"),
            Word("chicken", "kurczak"),
            Word("sausage", "kiełbasa"),
            Word("carrot", "marchewka"),
            Word("cabbage", "kapusta"),
            Word("pea", "groszek"),
            Word("potato", "ziemniak"),
            Word("tomato", "pomidor"),
            Word("apple", "jabłko"),
            Word("banana", "banan"),
            Word("orange", "pomarańcza"),
            Word("pear", "gruszka"),
            Word("pizza", "pizza"),
            Word("hamburger", "hamburger"),
            Word("spaghetti", "spaghetti"),
            Word("crisps", "chipsy"),
            Word("sandwich", "kanapka"),
            Word("cake", "ciasto"),
            Word("sweets", "słodycze"),
            Word("ice cream", "lody"),
            Word("fizzy drink", "napój gazowany"),
            Word("juice", "sok"),
            Word("milk", "mleko"),
            Word("water", "woda"),
            Word("meat", "mięso"),
            Word("fruit", "owoce"),
            Word("vegetables", "warzywa")
        )
    ),
    VocabularyCategory(
        id = "days",
        name = "Dni",
        words = listOf(
            Word("monday", "poniedziałek"),
            Word("tuesday", "wtorek"),
            Word("wednesday", "środa"),
            Word("thursday", "czwartek"),
            Word("friday", "piątek"),
            Word("saturday", "sobota"),
            Word("sunday", "niedziela")
        )
    ),
    VocabularyCategory(
        id = "school",
        name = "Szkola",
        words = listOf(
            Word("school", "szkoła"),
            Word("classroom", "klasa"),
            Word("teacher", "nauczyciel"),
            Word("student", "uczeń"),
            Word("desk", "ławka"),
            Word("chair", "krzesło"),
            Word("board", "tablica"),
            Word("book", "książka"),
            Word("notebook", "zeszyt"),
            Word("pen", "długopis"),
            Word("pencil", "ołówek"),
            Word("rubber", "gumka"),
            Word("ruler", "linijka"),
            Word("backpack", "plecak")
        )
    ),
    VocabularyCategory(
        id = "home",
        name = "Dom",
        words = listOf(
            Word("house", "dom"),
            Word("room", "pokój"),
            Word("kitchen", "kuchnia"),
            Word("bathroom", "łazienka"),
            Word("bedroom", "sypialnia"),
            Word("living room", "salon"),
            Word("garden", "ogród"),
            Word("door", "drzwi"),
            Word("window", "okno"),
            Word("bed", "łóżko"),
            Word("table", "stół")
        )
    ),
    VocabularyCategory(
        id = "animals",
        name = "Zwierzęta",
        words = listOf(
            Word("dog", "pies"),
            Word("cat", "kot"),
            Word("bird", "ptak"),
            Word("fish", "ryba"),
            Word("rabbit", "królik"),
            Word("hamster", "chomik"),
            Word("horse", "koń"),
            Word("cow", "krowa"),
            Word("pig", "świnia"),
            Word("sheep", "owca")
        )
    ),
    VocabularyCategory(
        id = "actions",
        name = "Czynności",
        words = listOf(
            Word("run", "biegać"),
            Word("walk", "chodzić"),
            Word("jump", "skakać"),
            Word("swim", "pływać"),
            Word("read", "czytać"),
            Word("write", "pisać"),
            Word("eat", "jeść"),
            Word("drink", "pić"),
            Word("sleep", "spać"),
            Word("play", "bawić się"),
            Word("watch", "oglądać"),
            Word("listen", "słuchać")
        )
    )
)

val allVerbs = listOf(
    VerbCategory(
        id = "czasowniki_1-3",
        name = "Czasowniki nieregularne (1-3)",
        verbs = listOf(
            IrregularVerb("go", "went", "gone", "iść"),
            IrregularVerb("eat", "ate", "eaten", "jeść"),
            IrregularVerb("drink", "drank", "drunk", "pić"),
            IrregularVerb("run", "ran", "run", "biegać"),
            IrregularVerb("see", "saw", "seen", "widzieć"),
            IrregularVerb("give", "gave", "given", "dawać"),
            IrregularVerb("take", "took", "taken", "brać"),
            IrregularVerb("come", "came", "come", "przychodzić"),
            IrregularVerb("do", "did", "done", "robić"),
            IrregularVerb("have", "had", "had", "mieć"),
            IrregularVerb("make", "made", "made", "robić"),
            IrregularVerb("sit", "sat", "sat", "siedzieć"),
            IrregularVerb("sleep", "slept", "slept", "spać"),
            IrregularVerb("read", "read", "read", "czytać"),
            IrregularVerb("write", "wrote", "written", "pisać"),
            IrregularVerb("sing", "sang", "sung", "śpiewać"),
            IrregularVerb("begin", "began", "begun", "zaczynać"),
            IrregularVerb("find", "found", "found", "znaleźć"),
            IrregularVerb("buy", "bought", "bought", "kupować"),
            IrregularVerb("bring", "brought", "brought", "przynosić")
        )
    ),
    VerbCategory(
        id = "czasowniki_4-6",
        name = "Czasowniki nieregularne (4-6)",
        verbs = listOf(
            IrregularVerb("be", "was/were", "been", "być"),
            IrregularVerb("begin", "began", "begun", "zaczynać"),
            IrregularVerb("break", "broke", "broken", "łamać"),
            IrregularVerb("bring", "brought", "brought", "przynosić"),
            IrregularVerb("buy", "bought", "bought", "kupować"),
            IrregularVerb("come", "came", "come", "przychodzić"),
            IrregularVerb("do", "did", "done", "robić"),
            IrregularVerb("drink", "drank", "drunk", "pić"),
            IrregularVerb("drive", "drove", "driven", "prowadzić"),
            IrregularVerb("eat", "ate", "eaten", "jeść"),
            IrregularVerb("find", "found", "found", "znaleźć"),
            IrregularVerb("forget", "forgot", "forgotten", "zapominać"),
            IrregularVerb("get", "got", "got", "dostać"),
            IrregularVerb("give", "gave", "given", "dawać"),
            IrregularVerb("go", "went", "gone", "iść"),
            IrregularVerb("have", "had", "had", "mieć"),
            IrregularVerb("know", "knew", "known", "wiedzieć"),
            IrregularVerb("make", "made", "made", "robić"),
            IrregularVerb("read", "read", "read", "czytać"),
            IrregularVerb("run", "ran", "run", "biegać"),
            IrregularVerb("say", "said", "said", "mówić"),
            IrregularVerb("see", "saw", "seen", "widzieć"),
            IrregularVerb("sing", "sang", "sung", "śpiewać"),
            IrregularVerb("sit", "sat", "sat", "siedzieć"),
            IrregularVerb("sleep", "slept", "slept", "spać"),
            IrregularVerb("speak", "spoke", "spoken", "mówić"),
            IrregularVerb("take", "took", "taken", "brać"),
            IrregularVerb("think", "thought", "thought", "myśleć"),
            IrregularVerb("write", "wrote", "written", "pisać")
        )
    )
)
