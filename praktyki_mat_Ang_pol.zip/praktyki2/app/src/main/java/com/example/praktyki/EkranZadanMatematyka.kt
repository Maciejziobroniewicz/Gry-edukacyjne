package com.example.praktyki

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

@Composable
fun EkranZadanMatematyka(category: String) {
    var numValue by remember { mutableIntStateOf(0) }
    var romanValue by remember { mutableStateOf("") }
    var num1 by remember { mutableIntStateOf(0) }
    var num2 by remember { mutableIntStateOf(0) }
    
    // Dla porównywania
    var dotsCount by remember { mutableIntStateOf(0) }
    var linesCount by remember { mutableIntStateOf(0) }
    
    var userAnswer by remember { mutableStateOf("") }
    var feedback by remember { mutableStateOf("") }
    var isCorrect by remember { mutableStateOf<Boolean?>(null) }
    var score by remember { mutableIntStateOf(0) }
    var totalQuestions by remember { mutableIntStateOf(0) }

    val romanMap = listOf(
        10 to "X", 9 to "IX", 5 to "V", 4 to "IV", 1 to "I"
    )

    fun toRoman(number: Int): String {
        var n = number
        var res = ""
        for ((value, roman) in romanMap) {
            while (n >= value) {
                res += roman
                n -= value
            }
        }
        return res
    }

    fun generateQuestion() {
        when (category) {
            "dodawanie_10" -> {
                num1 = Random.nextInt(1, 10)
                num2 = Random.nextInt(1, 10 - num1 + 1)
            }
            "odejmowanie_10" -> {
                num1 = Random.nextInt(2, 11)
                num2 = Random.nextInt(1, num1)
            }
            "dodawanie_100" -> {
                num1 = Random.nextInt(1, 100)
                num2 = Random.nextInt(1, 100 - num1 + 1)
            }
            "odejmowanie_100" -> {
                num1 = Random.nextInt(10, 101)
                num2 = Random.nextInt(1, num1)
            }
            "mnozenie_100" -> {
                num1 = Random.nextInt(2, 11)
                num2 = Random.nextInt(2, (100 / num1) + 1)
            }
            "dzielenie_100" -> {
                num2 = Random.nextInt(2, 11)
                val result = Random.nextInt(2, (100 / num2) + 1)
                num1 = num2 * result
            }
            "rzymskie_20" -> {
                numValue = Random.nextInt(1, 21)
                romanValue = toRoman(numValue)
            }
            "porownywanie" -> {
                dotsCount = Random.nextInt(1, 11)
                linesCount = Random.nextInt(1, 11)
                if (dotsCount == linesCount) linesCount = (linesCount % 10) + 1
            }
        }
        userAnswer = ""
        isCorrect = null
        feedback = ""
    }

    LaunchedEffect(category) {
        generateQuestion()
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = when(category) {
                "dodawanie_10" -> "Dodawanie do 10"
                "odejmowanie_10" -> "Odejmowanie do 10"
                "dodawanie_100" -> "Dodawanie do 100"
                "odejmowanie_100" -> "Odejmowanie do 100"
                "mnozenie_100" -> "Mnożenie do 100"
                "dzielenie_100" -> "Dzielenie do 100"
                "rzymskie_20" -> "Liczby rzymskie"
                "porownywanie" -> "Czego jest więcej?"
                else -> "Matematyka"
            },
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.primary
        )

        Text(text = "Wynik: $score / $totalQuestions", modifier = Modifier.padding(vertical = 16.dp))

        Spacer(modifier = Modifier.height(24.dp))

        if (category == "porownywanie") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Kropki", fontWeight = FontWeight.Bold)
                    Box(
                        modifier = Modifier
                            .size(120.dp)
                            .padding(8.dp)
                            .border(2.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column {
                            repeat((dotsCount + 2) / 3) { rowIndex ->
                                Row {
                                    repeat(minOf(3, dotsCount - rowIndex * 3)) {
                                        Box(
                                            modifier = Modifier
                                                .padding(4.dp)
                                                .size(16.dp)
                                                .background(Color.Red, CircleShape)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Kreski", fontWeight = FontWeight.Bold)
                    Box(
                        modifier = Modifier
                            .size(120.dp)
                            .padding(8.dp)
                            .border(2.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            repeat(linesCount) {
                                Box(
                                    modifier = Modifier
                                        .padding(horizontal = 2.dp)
                                        .width(4.dp)
                                        .height(30.dp)
                                        .background(Color.Blue)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            if (isCorrect == null) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Button(onClick = {
                        if (dotsCount > linesCount) {
                            isCorrect = true
                            feedback = "Brawo! Kropek jest więcej."
                            score++
                        } else {
                            isCorrect = false
                            feedback = "Błąd! Kresek jest więcej."
                        }
                        totalQuestions++
                    }) {
                        Text("Więcej KROPEK")
                    }
                    Button(onClick = {
                        if (linesCount > dotsCount) {
                            isCorrect = true
                            feedback = "Brawo! Kresek jest więcej."
                            score++
                        } else {
                            isCorrect = false
                            feedback = "Błąd! Kropek jest więcej."
                        }
                        totalQuestions++
                    }) {
                        Text("Więcej KRESEK")
                    }
                }
            }
        } else if (category == "rzymskie_20") {
            Text(text = "Ile to w systemie arabskim?", fontSize = 18.sp)
            Text(text = romanValue, fontSize = 64.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(vertical = 24.dp))
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                val sign = when {
                    category.startsWith("dodawanie") -> "+"
                    category.startsWith("odejmowanie") -> "-"
                    category.startsWith("mnozenie") -> "·"
                    else -> ":"
                }
                Text(text = "$num1", fontSize = 48.sp, fontWeight = FontWeight.Bold)
                Text(text = " $sign ", fontSize = 40.sp, modifier = Modifier.padding(horizontal = 8.dp))
                Text(text = "$num2", fontSize = 48.sp, fontWeight = FontWeight.Bold)
                Text(text = " = ", fontSize = 40.sp)
            }
        }

        if (category != "porownywanie") {
            Spacer(modifier = Modifier.height(32.dp))
            OutlinedTextField(
                value = userAnswer,
                onValueChange = { if (it.all { char -> char.isDigit() }) userAnswer = it },
                label = { Text("Twoja odpowiedź") },
                modifier = Modifier.width(180.dp),
                singleLine = true,
                textStyle = LocalTextStyle.current.copy(fontSize = 24.sp, fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(24.dp))
        }

        if (isCorrect == null) {
            if (category != "porownywanie") {
                Button(
                    onClick = {
                        val correct = if (category == "rzymskie_20") numValue else when {
                            category.startsWith("dodawanie") -> num1 + num2
                            category.startsWith("odejmowanie") -> num1 - num2
                            category.startsWith("mnozenie") -> num1 * num2
                            else -> num1 / num2
                        }
                        if (userAnswer.toIntOrNull() == correct) {
                            isCorrect = true
                            feedback = "Doskonale!"
                            score++
                        } else {
                            isCorrect = false
                            feedback = "Błąd! Poprawny wynik to $correct"
                        }
                        totalQuestions++
                    },
                    enabled = userAnswer.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth().height(56.dp)
                ) {
                    Text("SPRAWDŹ")
                }
            }
        } else {
            Text(
                text = feedback,
                color = if (isCorrect == true) Color(0xFF2E7D32) else Color(0xFFC62828),
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                modifier = Modifier.padding(vertical = 16.dp)
            )
            Button(onClick = { generateQuestion() }, modifier = Modifier.fillMaxWidth().height(56.dp)) {
                Text("NASTĘPNE")
            }
        }
    }
}
