package com.example.praktyki

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun EkranKlasy(subject: String, klasa: String, onNavigate: (String) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val displaySubject = when(subject) {
            "polski" -> "Język polski"
            "angielski" -> "Język angielski"
            "matematyka" -> "Matematyka"
            else -> subject
        }

        Text(
            text = "Klasa $klasa - $displaySubject",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(vertical = 24.dp)
        )

        val kategorie = when(subject) {
            "polski" -> listOf(
                "rz / ż" to "rz_z",
                "h / ch" to "h_ch",
                "u / ó" to "u_o",
                "Mieszane" to "mieszane"
            )
            "angielski" -> listOf(
                "Słówka" to "slowka",
                "Czasowniki nieregularne" to "czasowniki"
            )
            else -> listOf("Zadania" to "zadania")
        }

        kategorie.forEach { (label, slug) ->
            Button(
                onClick = { 
                    when {
                        subject == "polski" -> onNavigate("wybor_dyktanda/$klasa/$slug")
                        subject == "angielski" && slug == "slowka" -> onNavigate("wybor_slowek/$klasa")
                        // ZMIANA: Przesyłamy ID kategorii zależne od klasy
                        subject == "angielski" && slug == "czasowniki" -> onNavigate("zadania/angielski/$klasa/czasowniki_$klasa")
                        else -> onNavigate("zadania/$subject/$klasa/$slug")
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .height(64.dp),
                shape = MaterialTheme.shapes.medium
            ) {
                Text(label, fontSize = 20.sp)
            }
        }
    }
}
