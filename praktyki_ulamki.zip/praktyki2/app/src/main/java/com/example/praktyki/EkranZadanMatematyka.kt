package com.example.praktyki

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

@Composable
fun EkranZadanMatematyka(category: String) {
    var numValue by rememberSaveable { mutableIntStateOf(0) }
    var romanValue by rememberSaveable { mutableStateOf("") }
    var num1 by rememberSaveable { mutableIntStateOf(0) }
    var num2 by rememberSaveable { mutableIntStateOf(0) }
    
    // Pola dla ułamków
    var numU1 by rememberSaveable { mutableIntStateOf(0) }
    var denU1 by rememberSaveable { mutableIntStateOf(1) }
    var numU2 by rememberSaveable { mutableIntStateOf(0) }
    var denU2 by rememberSaveable { mutableIntStateOf(1) }
    var correctNum by rememberSaveable { mutableIntStateOf(0) }
    var correctDen by rememberSaveable { mutableIntStateOf(1) }
    
    var dotsCount by rememberSaveable { mutableIntStateOf(0) }
    var linesCount by rememberSaveable { mutableIntStateOf(0) }
    
    var userAnswer by rememberSaveable { mutableStateOf("") }
    var userAnswerDen by rememberSaveable { mutableStateOf("") } // Dla mianownika
    
    var feedback by rememberSaveable { mutableStateOf("") }
    var isCorrect by rememberSaveable { mutableStateOf<Boolean?>(null) }
    var score by rememberSaveable { mutableIntStateOf(0) }
    var totalQuestions by rememberSaveable { mutableIntStateOf(0) }
    
    var hasInitialized by rememberSaveable { mutableStateOf(false) }

    val romanMap = listOf(
        1000 to "M", 900 to "CM", 500 to "D", 400 to "CD",
        100 to "C", 90 to "XC", 50 to "L", 40 to "XL",
        10 to "X", 9 to "IX", 5 to "V", 4 to "IV", 1 to "I"
    )

    fun toRoman(number: Int): String {
        var n = number; var res = ""
        for ((value, roman) in romanMap) { while (n >= value) { res += roman; n -= value } }
        return res
    }

    fun generateQuestion() {
        val maxRoman = if (category.contains("1000")) 1001 else 21
        
        when (category) {
            "dodawanie_10" -> {
                num1 = Random.nextInt(1, 10); num2 = Random.nextInt(1, 10 - num1 + 1)
            }
            "odejmowanie_10" -> {
                num1 = Random.nextInt(2, 11); num2 = Random.nextInt(1, num1)
            }
            "dodawanie_100" -> {
                num1 = Random.nextInt(1, 100); num2 = Random.nextInt(1, 100 - num1 + 1)
            }
            "odejmowanie_100" -> {
                num1 = Random.nextInt(10, 101); num2 = Random.nextInt(1, num1)
            }
            "mnozenie_100" -> {
                num1 = Random.nextInt(2, 11); num2 = Random.nextInt(2, (100 / num1) + 1)
            }
            "dzielenie_100" -> {
                num2 = Random.nextInt(2, 11)
                val result = Random.nextInt(2, (100 / num2) + 1)
                num1 = num2 * result
            }
            "rzymskie_20", "rzymskie_1000" -> {
                numValue = Random.nextInt(1, maxRoman); romanValue = toRoman(numValue)
            }
            "rzymskie_wpisywanie", "rzymskie_wpisywanie_1000" -> {
                numValue = Random.nextInt(1, maxRoman); romanValue = toRoman(numValue)
            }
            "porownywanie" -> {
                dotsCount = Random.nextInt(1, 11); linesCount = Random.nextInt(1, 11)
            }
            "ulamki_dodaj_sam", "ulamki_odejmij_sam" -> {
                denU1 = Random.nextInt(2, 10)
                denU2 = denU1
                if (category == "ulamki_dodaj_sam") {
                    numU1 = Random.nextInt(1, denU1)
                    numU2 = Random.nextInt(1, denU1)
                    correctNum = numU1 + numU2
                    correctDen = denU1
                } else {
                    numU1 = Random.nextInt(2, 10)
                    numU2 = Random.nextInt(1, numU1)
                    correctNum = numU1 - numU2
                    correctDen = denU1
                }
            }
            "ulamki_dodaj_rozne", "ulamki_odejmij_rozne" -> {
                denU1 = Random.nextInt(2, 7)
                denU2 = Random.nextInt(2, 7)
                while(denU1 == denU2) denU2 = Random.nextInt(2, 7)
                
                numU1 = Random.nextInt(1, 5)
                numU2 = Random.nextInt(1, 5)
                
                if (category == "ulamki_dodaj_rozne") {
                    correctNum = numU1 * denU2 + numU2 * denU1
                    correctDen = denU1 * denU2
                } else {
                    if (numU1 * denU2 < numU2 * denU1) {
                        val tempN = numU1; val tempD = denU1
                        numU1 = numU2; denU1 = denU2
                        numU2 = tempN; denU2 = tempD
                    }
                    correctNum = numU1 * denU2 - numU2 * denU1
                    correctDen = denU1 * denU2
                }
            }
        }
        userAnswer = ""; userAnswerDen = ""
        isCorrect = null; feedback = ""
    }

    LaunchedEffect(category) { if (!hasInitialized) { generateQuestion(); hasInitialized = true } }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp).verticalScroll(scrollState),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = when {
                category == "dodawanie_10" -> "Dodawanie do 10"
                category == "odejmowanie_10" -> "Odejmowanie do 10"
                category == "dodawanie_100" -> "Dodawanie do 100"
                category == "odejmowanie_100" -> "Odejmowanie do 100"
                category == "mnozenie_100" -> "Mnożenie do 100"
                category == "dzielenie_100" -> "Dzielenie do 100"
                category.startsWith("rzymskie_wpisywanie") -> "Wpisywanie rzymskich"
                category.startsWith("rzymskie") -> "Odczytywanie rzymskich"
                category == "porownywanie" -> "Porównywanie"
                category.startsWith("ulamki") -> "Ułamki"
                else -> "Matematyka"
            },
            style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary
        )

        Text(text = "Wynik: $score / $totalQuestions", modifier = Modifier.padding(vertical = 16.dp))

        Spacer(modifier = Modifier.height(24.dp))

        if (category.startsWith("ulamki")) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$numU1", fontSize = 32.sp, fontWeight = FontWeight.Bold)
                    HorizontalDivider(modifier = Modifier.width(40.dp), thickness = 2.dp, color = Color.Black)
                    Text("$denU1", fontSize = 32.sp, fontWeight = FontWeight.Bold)
                }
                Text(if (category.contains("dodaj")) " + " else " - ", fontSize = 40.sp, modifier = Modifier.padding(horizontal = 8.dp))
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$numU2", fontSize = 32.sp, fontWeight = FontWeight.Bold)
                    HorizontalDivider(modifier = Modifier.width(40.dp), thickness = 2.dp, color = Color.Black)
                    Text("$denU2", fontSize = 32.sp, fontWeight = FontWeight.Bold)
                }
                Text(" = ", fontSize = 40.sp)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    OutlinedTextField(
                        value = userAnswer,
                        onValueChange = { if (it.all { c -> c.isDigit() }) userAnswer = it },
                        modifier = Modifier.width(70.dp),
                        textStyle = LocalTextStyle.current.copy(textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontSize = 20.sp),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                    HorizontalDivider(modifier = Modifier.width(70.dp).padding(vertical = 4.dp), thickness = 2.dp, color = Color.Black)
                    OutlinedTextField(
                        value = userAnswerDen,
                        onValueChange = { if (it.all { c -> c.isDigit() }) userAnswerDen = it },
                        modifier = Modifier.width(70.dp),
                        textStyle = LocalTextStyle.current.copy(textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontSize = 20.sp),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                }
            }
        } else if (category == "porownywanie") {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Kropki", fontWeight = FontWeight.Bold)
                    Box(modifier = Modifier.size(120.dp).padding(8.dp).border(2.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                        Column { repeat((dotsCount + 2) / 3) { r -> Row { repeat(minOf(3, dotsCount - r * 3)) { Box(modifier = Modifier.padding(4.dp).size(16.dp).background(Color.Red, CircleShape)) } } } }
                    }
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Kreski", fontWeight = FontWeight.Bold)
                    Box(modifier = Modifier.size(120.dp).padding(8.dp).border(2.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                        Row(verticalAlignment = Alignment.CenterVertically) { repeat(linesCount) { Box(modifier = Modifier.padding(horizontal = 2.dp).width(4.dp).height(30.dp).background(Color.Blue)) } }
                    }
                }
            }
            Spacer(modifier = Modifier.height(32.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                listOf(">", "=", "<").forEach { op ->
                    Button(
                        onClick = {
                            isCorrect = when(op) {
                                ">" -> dotsCount > linesCount
                                "=" -> dotsCount == linesCount
                                else -> dotsCount < linesCount
                            }
                            if (isCorrect == true) score++
                            feedback = if (isCorrect == true) "Brawo!" else "Błąd!"
                            totalQuestions++
                        },
                        enabled = isCorrect == null,
                        modifier = Modifier.size(70.dp).padding(4.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) { Text(op, fontSize = 28.sp, fontWeight = FontWeight.Bold) }
                }
            }
        } else if (category.startsWith("rzymskie") && !category.contains("wpisywanie")) {
            Text(text = "Ile to w systemie arabskim?", fontSize = 18.sp)
            Text(text = romanValue, fontSize = 64.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(vertical = 24.dp))
        } else if (category.startsWith("rzymskie_wpisywanie")) {
            Text(text = "Napisz tę liczbę rzymskimi znakami:", fontSize = 18.sp)
            Text(text = "$numValue", fontSize = 64.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(vertical = 24.dp))
            
            @OptIn(ExperimentalLayoutApi::class)
            FlowRow(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, maxItemsInEachRow = 4) {
                listOf("I", "V", "X", "L", "C", "D", "M").forEach { char ->
                    OutlinedButton(onClick = { if (isCorrect == null) userAnswer += char }, modifier = Modifier.padding(4.dp)) { Text(char, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                }
                OutlinedButton(onClick = { if (isCorrect == null && userAnswer.isNotEmpty()) userAnswer = userAnswer.dropLast(1) }, modifier = Modifier.padding(4.dp)) { Text("⌫", fontSize = 20.sp, color = Color.Red) }
            }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                val sign = when { category.startsWith("dodawanie") -> "+" ; category.startsWith("odejmowanie") -> "-" ; category.startsWith("mnozenie") -> "·" ; else -> ":" }
                Text(text = "$num1", fontSize = 48.sp, fontWeight = FontWeight.Bold)
                Text(text = " $sign ", fontSize = 40.sp, modifier = Modifier.padding(horizontal = 8.dp))
                Text(text = "$num2", fontSize = 48.sp, fontWeight = FontWeight.Bold)
                Text(text = " = ", fontSize = 40.sp)
            }
        }

        if (category != "porownywanie" && !category.startsWith("ulamki")) {
            Spacer(modifier = Modifier.height(32.dp))
            OutlinedTextField(
                value = userAnswer,
                onValueChange = { 
                    if (category.startsWith("rzymskie_wpisywanie")) { if (it.all { c -> c.uppercaseChar() in "IVXLCDM" }) userAnswer = it.uppercase() }
                    else { if (it.all { char -> char.isDigit() }) userAnswer = it }
                },
                label = { Text(if (category.startsWith("rzymskie_wpisywanie")) "Wpisz rzymską" else "Twoja odpowiedź") },
                modifier = Modifier.width(220.dp),
                singleLine = true,
                textStyle = LocalTextStyle.current.copy(fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center),
                keyboardOptions = KeyboardOptions(keyboardType = if (category.startsWith("rzymskie_wpisywanie")) KeyboardType.Text else KeyboardType.Number)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        if (isCorrect == null) {
            if (category != "porownywanie") {
                Button(
                    onClick = {
                        val isAnswerCorrect = when {
                            category.startsWith("ulamki") -> {
                                val uN = userAnswer.toIntOrNull() ?: 0
                                val uD = userAnswerDen.toIntOrNull() ?: 1
                                uN * correctDen == correctNum * uD && uD != 0
                            }
                            category.startsWith("rzymskie") && !category.contains("wpisywanie") -> userAnswer.toIntOrNull() == numValue
                            category.startsWith("rzymskie_wpisywanie") -> userAnswer.trim().uppercase() == romanValue
                            else -> {
                                val res = when { category.startsWith("dodawanie") -> num1 + num2; category.startsWith("odejmowanie") -> num1 - num2; category.startsWith("mnozenie") -> num1 * num2; else -> num1 / num2 }
                                userAnswer.toIntOrNull() == res
                            }
                        }

                        if (isAnswerCorrect) { isCorrect = true; feedback = "Doskonale!"; score++ }
                        else { isCorrect = false; feedback = "Błąd! Poprawny wynik to " + (if(category.startsWith("ulamki")) "$correctNum/$correctDen" else if(category.startsWith("rzymskie_wpisywanie")) romanValue else numValue.toString()) }
                        totalQuestions++
                    },
                    enabled = userAnswer.isNotEmpty() && (if(category.startsWith("ulamki")) userAnswerDen.isNotEmpty() else true),
                    modifier = Modifier.fillMaxWidth().height(56.dp)
                ) { Text("SPRAWDŹ", fontSize = 18.sp) }
            }
        } else {
            Text(text = feedback, color = if (isCorrect == true) Color(0xFF2E7D32) else Color(0xFFC62828), fontWeight = FontWeight.Bold, fontSize = 20.sp, modifier = Modifier.padding(vertical = 16.dp))
            Button(onClick = { generateQuestion() }, modifier = Modifier.fillMaxWidth().height(56.dp), colors = ButtonDefaults.buttonColors(containerColor = if (isCorrect == true) Color(0xFF2E7D32) else Color(0xFFC62828))) { Text("NASTĘPNE", fontSize = 18.sp) }
        }
        Spacer(modifier = Modifier.height(100.dp))
    }
}
