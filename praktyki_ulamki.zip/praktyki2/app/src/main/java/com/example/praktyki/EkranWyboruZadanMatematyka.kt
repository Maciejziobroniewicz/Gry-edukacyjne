package com.example.praktyki

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun EkranWyboruZadanMatematyka(klasa: String, group: String, onNavigate: (String) -> Unit) {
    val tasks = when (group) {
        "dzialania" -> if (klasa == "1-3") {
            listOf(
                "Dodawanie do 10" to "dodawanie_10",
                "Odejmowanie do 10" to "odejmowanie_10"
            )
        } else {
            listOf(
                "Dodawanie do 100" to "dodawanie_100",
                "Odejmowanie do 100" to "odejmowanie_100",
                "Mnożenie do 100" to "mnozenie_100",
                "Dzielenie do 100" to "dzielenie_100"
            )
        }
        "ulamki" -> if (klasa == "1-3") {
            listOf(
                "Dodawanie ułamków (ten sam mianownik)" to "ulamki_dodaj_sam",
                "Odejmowanie ułamków (ten sam mianownik)" to "ulamki_odejmij_sam"
            )
        } else {
            listOf(
                "Dodawanie ułamków (różne mianowniki)" to "ulamki_dodaj_rozne",
                "Odejmowanie ułamków (różne mianowniki)" to "ulamki_odejmij_rozne"
            )
        }
        "rzymskie" -> if (klasa == "4-6") {
            listOf(
                "Odczytywanie rzymskich do 1000" to "rzymskie_1000",
                "Wpisywanie rzymskich do 1000" to "rzymskie_wpisywanie_1000"
            )
        } else {
            listOf(
                "Odczytywanie rzymskich do 20" to "rzymskie_20",
                "Wpisywanie rzymskich do 20" to "rzymskie_wpisywanie"
            )
        }
        "porownywanie" -> listOf(
            "Mniej, więcej (Kropki i kreski)" to "porownywanie"
        )
        else -> emptyList()
    }

    val title = when (group) {
        "dzialania" -> "Działania matematyczne"
        "ulamki" -> "Ułamki"
        "rzymskie" -> "Liczby rzymskie"
        "porownywanie" -> "Porównywanie"
        else -> "Wybierz zadanie"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        if (tasks.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Brak zadań w tej kategorii dla Twojej klasy.")
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(tasks) { (label, slug) ->
                    Card(
                        onClick = { onNavigate("zadania/matematyka/$klasa/$slug") },
                        modifier = Modifier.fillMaxWidth(),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .padding(20.dp)
                                .fillMaxWidth(),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(text = label, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }
    }
}
