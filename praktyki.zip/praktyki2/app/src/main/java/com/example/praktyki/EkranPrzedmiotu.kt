package com.example.praktyki

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun EkranPrzedmiotu(subject: String, onNavigate: (String) -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Wybrano przedmiot: $subject")
        Button(onClick = { onNavigate("klasa/1") }) {
            Text("Klasa 1")
        }
        Button(onClick = { onNavigate("klasa/2-3") }) {
            Text("Klasa 2-3")
        }
        Button(onClick = { onNavigate("klasa/4-5") }) {
            Text("Klasa 4-5")
        }
    }
}
