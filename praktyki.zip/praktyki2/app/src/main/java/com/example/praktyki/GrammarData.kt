package com.example.praktyki

data class GrammarOptionTask(
    val sentenceBefore: String,
    val options: List<String>,
    val correctOption: String,
    val sentenceAfter: String
)

data class GrammarFillInTask(
    val sentenceBefore: String,
    val verb: String,
    val correctAnswer: String,
    val sentenceAfter: String
)

object GrammarTasks {
    // Zadania "Wybierz właściwą formę"
    val presentSimpleOptions13 = listOf(
        GrammarOptionTask("My husband never", listOf("lie", "lies"), "lies", "to anybody."),
        GrammarOptionTask("You often", listOf("smile", "smiles"), "smile", "to people you meet."),
        GrammarOptionTask("Children", listOf("become", "becomes"), "become", "healthier if they are loved."),
        GrammarOptionTask("They", listOf("play", "plays"), "play", "tennis twice a week."),
        GrammarOptionTask("The students", listOf("study", "studies"), "study", "German and English."),
        GrammarOptionTask("I usually", listOf("drink", "drinks"), "drink", "one coffee a day."),
        GrammarOptionTask("It often", listOf("rain", "rains"), "rains", "in autumn in my homeland."),
        GrammarOptionTask("The postman", listOf("bring", "brings"), "brings", "me my mail every other day."),
        GrammarOptionTask("My brother often", listOf("play", "plays"), "plays", "football."),
        GrammarOptionTask("May", listOf("come", "comes"), "comes", "after April.")
    )

    // Zadania "Uzupełnij zdania" - Present Simple
    val presentSimpleFill13 = listOf(
        GrammarFillInTask("The shops in Poland usually", "open", "open", "quite early."),
        GrammarFillInTask("I always", "drink", "drink", "coffee in the morning."),
        GrammarFillInTask("It", "wake", "wakes", "me up."),
        GrammarFillInTask("My mother", "do", "does", "the shopping every afternoon."),
        GrammarFillInTask("I sometimes", "help", "help", "her."),
        GrammarFillInTask("They sometimes", "play", "play", "basketball at weekend."),
        GrammarFillInTask("My friend", "write", "writes", "poems and she's really good at it."),
        GrammarFillInTask("I", "read", "read", "many books."),
        GrammarFillInTask("My job", "need", "needs", "it."),
        GrammarFillInTask("Her brother hardly ever", "leave", "leaves", "home because he's very shy."),
        GrammarFillInTask("It never", "snow", "snows", "in Africa so it's a good place for summer holidays."),
        GrammarFillInTask("I", "hate", "hate", "spiders! They're awful!"),
        GrammarFillInTask("This car", "cost", "costs", "a lot of money but it is worth it.")
    )

    // Zadania "Uzupełnij zdania" - Present Continuous
    val presentContinuousFill13 = listOf(
        GrammarFillInTask("The lady over there", "speak", "is speaking", "on the phone."),
        GrammarFillInTask("My parents", "argue", "are arguing", "right now."),
        GrammarFillInTask("My brother", "take", "is taking", "his dog for a walk."),
        GrammarFillInTask("Sue", "go", "is going", "to church later."),
        GrammarFillInTask("Bob and Tom", "listen", "are listening", "to the radio."),
        GrammarFillInTask("Our company", "build", "is building", "a new station in town."),
        GrammarFillInTask("She", "sleep", "is sleeping", "in her bedroom."),
        GrammarFillInTask("The children", "draw", "are drawing", "in their room."),
        GrammarFillInTask("The sun", "shine", "is shining", "at the moment."),
        GrammarFillInTask("It", "rain", "is raining", "in Chicago today.")
    )

    // Zadania Present Perfect - Wybierz właściwą formę
    val presentPerfectOptions46 = listOf(
        GrammarOptionTask("My mum has just", listOf("makes", "make", "made", "making"), "made", "a delicious apple pie."),
        GrammarOptionTask("I have already", listOf("washed", "wash", "washing", "washes"), "washed", "up after dinner."),
        GrammarOptionTask("She has", listOf("takes", "taking", "taken", "took"), "taken", "the dog for a long walk."),
        GrammarOptionTask("My friends have just", listOf("called", "call", "calling", "calls"), "called", "me to congratulate me on passing the exam."),
        GrammarOptionTask("The dog has", listOf("running", "ran", "run", "runs"), "run", "across the street."),
        GrammarOptionTask("Bill has", listOf("pays", "paying", "paid", "pay"), "paid", "for us."),
        GrammarOptionTask("She has", listOf("swum", "swam", "swimming", "swimmed"), "swum", "one kilometer so far."),
        GrammarOptionTask("He has just", listOf("falls", "fell", "fallen", "falling"), "fallen", "from the tree."),
        GrammarOptionTask("The alarm has just", listOf("goes", "going", "went", "gone"), "gone", "off."),
        GrammarOptionTask("The TV serial has just", listOf("ended", "ends", "ending", "end"), "ended", ".")
    )

    // Zadania Present Perfect - Uzupełnij zdania
    val presentPerfectFill46 = listOf(
        GrammarFillInTask("They", "work", "have worked", "for the same company for ten years, so they know each other very well."),
        GrammarFillInTask("The train", "arrive", "has arrived", "."),
        GrammarFillInTask("We have to say goodbye now. I'm sorry. I", "forget", "have forgotten", "your name. Can you remind me, please?"),
        GrammarFillInTask("Nick", "find", "has found", "a job and he's busy all the time now."),
        GrammarFillInTask("Ann and Susan", "do", "have done", "a lot of work, so let them have a break now."),
        GrammarFillInTask("I", "read", "have read", "a lot of books, so I can talk confidently about literature."),
        GrammarFillInTask("It", "stop", "has stopped", "snowing, so we can go out at last."),
        GrammarFillInTask("Bill and I", "have", "have had", "a good time lately. We enjoy being together."),
        GrammarFillInTask("She", "meet", "has met", "him before. They once worked in the same office."),
        GrammarFillInTask("My parents", "travel", "have travelled", "the world and they can talk about their adventures for hours.")
    )
}
