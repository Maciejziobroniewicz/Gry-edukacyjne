package com.example.praktyki

data class VowelTask(val word: String, val vowelCount: Int)
data class LetterTypeTask(val letter: String, val isVowel: Boolean)

object PolishTasks {
    // Słowa do liczenia samogłosek (Klasa 1-3)
    val vowelWords13 = listOf(
        VowelTask("kot", 1), VowelTask("dom", 1), VowelTask("las", 1),
        VowelTask("pies", 2), VowelTask("mama", 2), VowelTask("tata", 2),
        VowelTask("kura", 2), VowelTask("lody", 2), VowelTask("woda", 2),
        VowelTask("okno", 2), VowelTask("auto", 3), VowelTask("ryba", 1),
        VowelTask("sowa", 2), VowelTask("buty", 2), VowelTask("oko", 2),
        VowelTask("ule", 2), VowelTask("kino", 2), VowelTask("balon", 2),
        VowelTask("cebula", 3), VowelTask("pomidor", 3)
    )

    // Słowa do liczenia samogłosek (Klasa 4-6)
    val vowelWords46 = listOf(
        VowelTask("szkoła", 2), VowelTask("zeszyt", 2), VowelTask("tablica", 3),
        VowelTask("komputer", 3), VowelTask("przyroda", 3), VowelTask("historia", 4),
        VowelTask("matematyka", 4), VowelTask("zadanie", 4), VowelTask("wakacje", 4),
        VowelTask("kolega", 3), VowelTask("koleżanka", 4), VowelTask("nauczyciel", 4),
        VowelTask("biblioteka", 5), VowelTask("rowerzysta", 3), VowelTask("śniadanie", 4),
        VowelTask("kanapka", 3), VowelTask("ogórek", 3), VowelTask("pomarańcza", 4),
        VowelTask("warzywo", 3), VowelTask("podróż", 2)
    )

    // Samogłoski i Spółgłoski
    val vowels = setOf("a", "ą", "e", "ę", "i", "o", "ó", "u", "y")
    val consonants = setOf(
        "b", "c", "ć", "d", "f", "g", "h", "j", "k", "l", "ł", "m", "n", "ń", "p", "r", "s", "ś", "t", "w", "z", "ź", "ż"
    )

    // Funkcja generująca losową listę liter do gry (np. 20 zadań)
    fun getLetterTypeTasks(): List<LetterTypeTask> {
        val allLetters = (vowels.map { LetterTypeTask(it, true) } + 
                          consonants.map { LetterTypeTask(it, false) })
        return allLetters.shuffled().take(20)
    }
}
