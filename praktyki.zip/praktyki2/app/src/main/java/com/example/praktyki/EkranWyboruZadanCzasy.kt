package com.example.praktyki

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun EkranWyboruZadanCzasy(klasa: String, tense: String, onNavigate: (String) -> Unit) {
    val tasks = when (tense) {
        "present_simple" -> listOf(
            "Wybierz właściwą formę czasownika" to "present_simple_options",
            "Uzupełnij zdania odpowiednią formą" to "present_simple_fill"
        )
        "present_continuous" -> listOf(
            "Uzupełnij zdania (am/is/are + -ing)" to "present_continuous_fill"
        )
        "present_perfect" -> if (klasa == "4-6") {
            listOf(
                "Wybierz właściwą formę czasownika" to "present_perfect_options",
                "Uzupełnij zdania (have/has + III forma)" to "present_perfect_fill"
            )
        } else emptyList()
        else -> emptyList()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Wybierz ćwiczenie",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(tasks) { (label, slug) ->
                Card(
                    onClick = { onNavigate("zadania/angielski/$klasa/$slug") },
                    modifier = Modifier.fillMaxWidth(),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .padding(20.dp)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(text = label, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}
