package com.example.praktyki

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.mapSaver
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

sealed class TextPart {
    data class Normal(val text: String) : TextPart()
    data class Gap(val id: Int, val correct: String, val options: List<String>) : TextPart()
}

fun parseDictationToWords(rawText: String, startId: Int, options: List<String>): Pair<List<List<TextPart>>, Int> {
    val wordsRaw = rawText.split(Regex("\\s+")).filter { it.isNotEmpty() }
    var currentId = startId
    val result = mutableListOf<List<TextPart>>()

    wordsRaw.forEach { word ->
        val wordParts = mutableListOf<TextPart>()
        val regex = "\\{([^}]+)\\}".toRegex()
        var lastIndex = 0

        regex.findAll(word).forEach { matchResult ->
            if (matchResult.range.first > lastIndex) {
                wordParts.add(TextPart.Normal(word.substring(lastIndex, matchResult.range.first)))
            }
            val correctValue = matchResult.groupValues[1]
            wordParts.add(TextPart.Gap(currentId++, correctValue, options))
            lastIndex = matchResult.range.last + 1
        }

        if (lastIndex < word.length) {
            wordParts.add(TextPart.Normal(word.substring(lastIndex)))
        }
        
        if (wordParts.isEmpty()) {
            wordParts.add(TextPart.Normal(word))
        }
        result.add(wordParts)
    }

    return result to currentId
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Dyktando(dictationId: String) {
    val dictation = allDictations.find { it.id == dictationId }

    if (dictation == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Nie znaleziono dyktanda.")
        }
        return
    }

    val options = when (dictation.category) {
        "rz_z" -> listOf("rz", "ż")
        "h_ch" -> listOf("h", "ch")
        "u_o" -> listOf("u", "ó")
        else -> listOf("rz", "ż", "h", "ch", "u", "ó")
    }

    val paragraphsParts = remember(dictation) {
        var idCounter = 1
        dictation.paragraphs.map { 
            val (parsedWords, nextId) = parseDictationToWords(it, idCounter, options)
            idCounter = nextId
            parsedWords
        }
    }

    // Specjalny sposób na zapamiętywanie mapy odpowiedzi przy obracaniu ekranu
    val userAnswers = rememberSaveable(
        saver = mapSaver(
            save = { it.mapKeys { entry -> entry.key.toString() } },
            restore = { 
                val map = mutableStateMapOf<Int, String>()
                it.forEach { (key, value) -> map[key.toInt()] = value as String }
                map
            }
        )
    ) { mutableStateMapOf<Int, String>() }

    var showResults by rememberSaveable { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = dictation.title,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        paragraphsParts.forEach { words ->
            FlowRow(
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                words.forEach { wordParts ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        wordParts.forEach { part ->
                            when (part) {
                                is TextPart.Normal -> {
                                    Text(text = part.text, fontSize = 18.sp, lineHeight = 28.sp)
                                }
                                is TextPart.Gap -> {
                                    val currentAnswer = userAnswers[part.id] ?: ""
                                    val isCorrect = currentAnswer.lowercase() == part.correct.lowercase()
                                    
                                    Surface(
                                        modifier = Modifier
                                            .padding(horizontal = 0.dp)
                                            .clickable {
                                                if (!showResults) {
                                                    val currentIndex = options.indexOf(currentAnswer.lowercase())
                                                    val nextIndex = (currentIndex + 1) % (options.size + 1)
                                                    userAnswers[part.id] = if (nextIndex < options.size) options[nextIndex] else ""
                                                }
                                            },
                                        color = when {
                                            !showResults -> MaterialTheme.colorScheme.surfaceVariant
                                            isCorrect -> Color(0xFFC8E6C9)
                                            else -> Color(0xFFFFCDD2)
                                        },
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = if (currentAnswer.isEmpty()) "_" else currentAnswer,
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = if (showResults) {
                                                if (isCorrect) Color(0xFF2E7D32) else Color(0xFFC62828)
                                            } else {
                                                MaterialTheme.colorScheme.onSurfaceVariant
                                            },
                                            modifier = Modifier.padding(horizontal = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = { 
                if (showResults) {
                    userAnswers.clear()
                    showResults = false
                } else {
                    showResults = true
                }
            },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(if (showResults) "SPRÓBUJ PONOWNIE" else "SPRAWDŹ WYNIK")
        }

        if (showResults) {
            val allGaps = paragraphsParts.flatten().flatten().filterIsInstance<TextPart.Gap>()
            val correctCount = allGaps.count { userAnswers[it.id]?.lowercase() == it.correct.lowercase() }
            
            Card(
                modifier = Modifier.padding(top = 24.dp).fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Text(
                    "Wynik: $correctCount / ${allGaps.size}",
                    modifier = Modifier.padding(16.dp).align(Alignment.CenterHorizontally),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Spacer(modifier = Modifier.height(40.dp))
    }
}
