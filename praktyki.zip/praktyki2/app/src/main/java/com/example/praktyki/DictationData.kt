package com.example.praktyki

data class Dictation(
    val id: String,
    val title: String,
    val klasa: String,
    val category: String,
    val paragraphs: List<String>
)

val allDictations = listOf(
    Dictation(
        id = "chleb_13",
        title = "Jak powstaje chleb?",
        klasa = "1-3",
        category = "rz_z",
        paragraphs = listOf(
            "{Ż}eby na stole mogło znaleźć się cieplutkie pieczywo, wielu ludzi musi wykonać ró{ż}ne czynności.",
            "Najpierw rolnik uprawia ziemię, a później sieje ziarna pszenicy i {ż}yta.",
            "Gdy zbo{ż}e po wykiełkowaniu trochę urośnie, dba, aby nie było w nim niepo{ż}ądanych roślin, czyli chwastów.",
            "Kiedy zbli{ż}ają się {ż}niwa, to ziarna twardnieją, a słoma {ż}ółknie.",
            "Wtedy na pola wyje{ż}dżają kombajny, {ż}eby wymłócić pszenicę i {ż}yto.",
            "Następnie rolnicy przywo{ż}ą zebrane plony do swoich gospodarstw.",
            "Sypią je do spichle{rz}y lub od razu jadą do punktu skupu, {ż}eby je sp{rz}edać.",
            "Jeśli ziarna pszenicy i {ż}yta są niskiej jakości, to będą p{rz}eznaczone na produkcję paszy.",
            "Natomiast najlepsze zbo{ż}a zostaną zawiezione do młynów.",
            "Młyna{rz}e zmielą je na mąkę.",
            "Trafi ona do magazynów, a stąd do sklepów, do cukierni lub do piekarni.",
            "Gdy znajdzie się w rękach pieka{rz}y, to powstaną z niej ró{ż}ne gatunki chleba i bułek.",
            "Zanim świe{ż}e pieczywo znajdzie się na naszym stole, to musi być p{rz}ewiezione do sklepów, aby ka{ż}dy mógł je kupić."
        )
    ),
    Dictation(
        id = "zima_13",
        title = "Zimowe zabawy",
        klasa = "1-3",
        category = "rz_z",
        paragraphs = listOf(
            "Zima to ulubiona pora roku Ma{rz}eny i Michała.",
            "Chętnie nakładają nowe ko{ż}uszki i ciepłe kozaki.",
            "Nie zapominają o bawełnianych czapkach, szalikach i rękawiczkach.",

            "Ich babcia ju{ż} dawno zostawiła jesienny płaszcz w szafie i chodzi teraz w fut{rz}e.",
            "Uwa{ż}a, {ż}e zimą jest pięknie.",
            "Podoba jej się, gdy wszędzie jest biały śnie{ż}ek.",
            "Chocia{ż} niekiedy na{rz}eka, {ż}e jest jej cię{ż}ko chodzić po świe{ż}o zasypanym chodniku, to jednak stara się, jak najwięcej czasu spędzić ze swoimi wnukami.",
            "Dlatego ka{ż}dego dnia, kiedy nie ma śnie{ż}ycy i gołoledzi, wychodzi z nimi na dwór.",
            "Zwykle spacerują blisko domu lub idą na sanki do parku.",

            "Dzieci czasem lepią bałwana.",
            "Najpierw toczą a{ż} t{rz}y kule ze śniegu, które następnie babcia ustawia jedna na drugiej.",
            "Później Ma{rz}ena i Michał z marchwi robią nos, a z węgla oczy i guziki.",
            "Ze śniegu doklejają śnie{ż}nej postaci ręce.",
            "Wkładają w nie starą miotłę.",
            "Długo pat{rz}ą na swoje dzieło i są bardzo dumne, gdy babcia mówi im, {ż}e ulepiły pięknego bałwanka."
        )
    ),
    Dictation(
        id = "las_13",
        title = "Wędrówka przez las",
        klasa = "1-3",
        category = "rz_z",
        paragraphs = listOf(
            "G{rz}eś i K{rz}yś bardzo lubią piesze wędrówki.",
            "Często chodzą z rodzicami do lasu.",
            "Podczas spaceru bawią się, biegając między ogromnymi d{rz}ewami.",
            "G{rz}eś zawsze chętnie ogląda białe b{rz}ozy rosnące nieopodal gęstych k{rz}ewów.",
            "Zauwa{ż}ył, {ż}e są one wysokie i mają piękne, zielone listki.",
            "Na ostatnim space{rz}e K{rz}yś uczył się zbierania g{rz}ybów.",
            "P{rz}ed wyjściem do lasu oglądał z tatą atlas g{rz}ybów.",
            "Później udało mu się znaleźć pięknego prawdziwka.",
            "Wło{ż}ył go do wiklinowego kosza.",

            "Chłopcy potrafią ju{ż} rozpoznać ró{ż}ne d{rz}ewa.",
            "Od niedawna mówią tacie: tu rosną wysokie b{rz}ozy, tam niedaleko ogromne dęby i iglaste jodły.",
            "Wiedzą równie{ż}, jak wygląda mech i gdzie mo{ż}na znaleźć dziuplę wiewiórki.",
            "Nie jest dla nich ju{ż} tajemnicą, gdzie mieszkają ptaki i zwie{rz}ęta.",
            "Czasami uda im się usłyszeć dzięcioła stukającego dziobem w pień d{rz}ewa lub zobaczyć sarenkę biegnącą do źródła.",
            "Ostatnio G{rz}eś widział stado dzików p{rz}echodzących p{rz}ez ście{ż}kę.",
            "Były one daleko.",
            "Nie mógł im się dokładnie p{rz}yj{rz}eć i dlatego później tata mówił mu, jaką mają sierść.",

            "Mama p{rz}ed końcem wędrówki zawsze p{rz}ypomina im, {ż}e pora zjeść kanapki.",
            "Wszyscy udają się na polanę, na której są drewniane stoły i ławki.",
            "Siadają i czekają, a{ż} mama wyjmie z taty plecaka zapakowany prowiant.",
            "Wszyscy z apetytem zjadają kanapki i piją ciepłą herbatę z termosu.",
            "Ju{ż} wtedy chłopcy z rodzicami planują kolejną wyprawę do lasu."
        )
    ),
    Dictation(
            id = "cukiernia_13",
    title = "Cukiernia",
    klasa = "1-3",
    category = "u_o",
    paragraphs = listOf(
        "Babcia Krysia pracowała w c{u}kierni u Kazia.",
        "Kakao, czekolada, cynamon, wanilia i mi{ó}d w jej rękach od razu znajdowały zastosowanie.",
        "Nie gardziła też bakaliami, do kt{ó}rych miała słabość.",
        "Dodawała je do keks{ó}w, m{e}rzynk{ó}w, maz{u}rk{ó}w i tr{u}fli.",

        "Piekła p{u}lchne baby drożdżowe, p{u}szyste biszkopty i wspaniałe serniczki.",
        "Klienci zachwycali się jej ciepl{u}tkimi b{u}łeczkami, kt{ó}re nadziewała jagodami, jabł{u}szkami, śliwkami, białym serem l{u}b b{u}dyniem waniliowym.",
        "Świe{ż}utkie szarlotki i drożdżowe str{u}cle k{u}siły swoimi polewami.",
        "D{u}mnie na p{ó}łkach prezentowały się r{ó}wnież torty.",
        "Na ich wierzch{u} były marcepanowe r{ó}{ż}yczki, płatki migdałowe, wiśnie, tr{u}skawki l{u}b kawałki owoc{ó}w mających mało sok{ó}w.",
        "L{u}krowane cytrynowe baby, opr{u}szone c{u}krem p{u}drem pączki nadziewane konfit{u}rą r{ó}{ż}aną i maślane rogaliki, oblane mleczną czekoladą pierniczki, w{u}zetki, ptysie i cynamonowe ciasteczka także zatrzymywały przechodni{ó}w.",
        "Zachwycały wyglądem i smakiem.",

        "Dlatego kto chociaż raz spr{ó}bował specjał{ó}w babci Krysi, ten wracał do c{u}kierni Kazia.",
        "Tajemnicą ich s{u}kcesu były wysokiej jakości składniki i tradycyjne recept{u}ry przekazywane z pokolenia na pokolenie."
    )
),
    Dictation(
        id = "Udziadkow_13",
        title = "U dziadków",
        klasa = "1-3",
        category = "mieszane",
        paragraphs = listOf(
            "Rano babcia {H}ania i dziadzi{u}ś Staś postanowili zrobić wn{u}czkom niespodziankę.",
            "Babcia upiekła tort z o{rz}echami, a dziadzi{u}ś k{u}pił bilet do wesołego miasteczka.",
            "Wieczorem gościli u siebie wnuczk{ó}w.",
            "Dzieciom smakował tort i podobała się jazda na kar{u}zeli."        )
    ),
    Dictation(
        id = "chorobachomika13",
        title = "Choroba chomika",
        klasa = "1-3",
        category = "h_ch",
        paragraphs = listOf(
            "{Ch}omik {H}ubert {ch}ciał od{ch}orować katar, przez który zwic{h}nął sobie nóżkę.",
            "Ki{ch}ając poje{ch}ał na {ch}odniku i wywinął orła z takim {h}ukiem, że {ch}rząszcz {H}erkules przytu{ch}tał co t{chu}.",
            "O{ch}ronił {ch}omika swoją pła{ch}tą i od{ch}olował do {ch}irurga.",
            "W przy{ch}odni {ch}omik st{ch}órzył i czmy{ch}nął do klatki."
        )
    ),
    Dictation(
        id = "pies46",
        title = "Pies",
        klasa = "4-6",
        category = "rz_z",
        paragraphs = listOf(
            "Najwierniejszym p{rz}yjacielem dla wielu ludzi jest pies.",
            "{Ż}wawo p{rz}ybiega do człowieka.",
            "Cieszy się, kiedy ma pełną miskę karmy i wygodne posłanie.",
            "Z p{rz}yjemnością chłepcze wodę.",
            "Uwielbia, gdy właściciel delikatnie czesze go g{rz}ebieniem.",
            "{Ż}ałośnie pat{rz}y na pana, który za krótko jest z nim na space{rz}e.",
            "St{rz}e{ż}e jego sekretów i pilnuje domu.",
            "Jest mądrym i wra{ż}liwym zwie{rz}ęciem.",
            "Du{ż}o rozumie i nigdy go nie zdradzi.",

            "Warczy i szcze{rz}y zęby, gdy w pobli{ż}u zobaczy kota.",
            "Wtedy nie zwa{ż}a na sp{rz}ęty znajdujące się w domu lub na podwórku.",
            "Nie dost{rz}ega tak{ż}e kwiatów i wa{rz}yw na g{rz}ądkach.",
            "Błyskawicznie gna za swoim wrogiem, bo nie znosi jego towa{rz}ystwa.",
            "Mimo, {ż}e widzi, i{ż} kot porusza się sp{rz}ę{ż}ystym krokiem po gałęziach d{rz}ew, to nie daje za wygraną.",
            "Cierpliwie czeka a{ż} niep{rz}yjaciel zrezygnuje z p{rz}echadzania się na wysokościach i będzie musiał zejść na ziemię.",
            "Ma nadzieję, {ż}e wtedy ponownie poka{ż}e mu kły, a kot p{rz}estraszy się i ucieknie z jego terytorium.",
            "Dzieje się tak, gdy{ż} p{rz}ewa{ż}nie pies nie znosi kota.",

            "W {ż}yciu mo{ż}na być wiernym jak pies, albo {ż}yje się jak pies z kotem.",
            "Wtedy obydwie osoby nie lubią się i często kłócą się.",
            "Jednak najlepiej {ż}yć w zgodzie z innymi i zawsze się wspierać."
        )
    ),
    Dictation(
        id = "nadzialce46",
        title = "Na działce",
        klasa = "4-6",
        category = "h_ch",
        paragraphs = listOf(
            "{H}alinka od godziny krzątała się na działce.",
            "Wyrywała {ch}wasty z {ch}abrów.",
            "Kiedy usłyszała odgłos {H}arleya, od razu wiedziała, że to przyje{ch}ał wujek Mi{ch}ał z {H}ajnówki, który zajmuje się {h}ydrologią.",
            "Gdy weszła do altanki, zobaczyła, że rodzice już z nim rozmawiali, a na stoliku stał dzbanek malinowej {h}erbatki i talerz kanapek z serkiem {h}omogenizowanym.",
            "Wujek podarował jej brązową {h}armonijkę i książkę.",
            "Tro{ch}ę z nimi pogawędziła o gminny{ch} {h}alowy{ch} mistrzostwa{ch} w lekkiej atletyce, w który{ch} brała udział.",
            "Potem pobiegła po {ch}odniczku do ogrodowego domku.",
            "Nasypała do miski karmy dla Reksa i mu ją zaniosła.",
            "Bardzo lubiła patrzeć, jak {chart}, który nigdy nie był {ch}erlakiem, {ch}ciwie zajadał najpierw wielkie kawałki oraz o{ch}oczo {ch}łeptał wodę.",
            "Mieli gościa i {ch}cąc nie {ch}cąc, nie mogła cały czas stać przed jego budą.",
            "Słyszała {ch}i{ch}ot dobiegający z altanki i była ciekawa, co i{ch} tak śmieszy.",
            "Kiedy poszła do ni{ch}, głośno od{ch}rząknęła i naty{ch}miast zaczęła za{ch}walać ich działkę jako miejsce, gdzie nie ma {h}ałasu i gdzie na próżno można wypatrywać {ch}mary komarów."        )
    ),
    Dictation(
        id = "slota46",
        title = "Słota",
        klasa = "4-6",
        category = "mieszane",
        paragraphs = listOf(
            "Kata{rz}yna, gdy się ob{u}dziła, to szybko wstała z ł{ó}żka.",
            "Podeszła do okna.",
            "Od{ch}yliła firankę i west{ch}nęła.",
            "– O{ch}, jaka b{r}zydka dziś pogoda! Słońce za {ch}mury się skryło.",
            "Wszędzie się za{ch}murzyło.",
            "Ciągle pada deszcz.",
            "Na dwo{r}ze jest szaro i sm{u}tno.",
            "Ja dziś nie idę do szkoły i nie mogę bawić się z p{rz}yjaci{ó}łmi na podw{ó}rku.",
            "Mo{ż}e poczytam sobie bajeczkę o księ{ż}niczce albo jakąś ksią{ż}kę o podr{ó}żach.",
            "Poproszę te{ż} rodzic{ó}w, {ż}ebyśmy poje{ch}ali do dziadk{ó}w."        )
    ),
    Dictation(
        id = "Dziadkowie46",
        title = "Dziadkowie",
        klasa = "4-6",
        category = "mieszane",
        paragraphs = listOf(
            "Moi dziadkowie nie patrzą na mnie krzywym okiem i cieszą się, kiedy ich odwiedzam.",
            "Są jak lekarstwo na moje {z}martwienia.",
            "Doradzą mi i zawsze coś miłego powiedzą.",
            "Wiedzą, jaki jest ostatni krzyk mody w sezonie, co jest grane w kinie, jakie nosi się {u}brania, jaki wyprodu{k}owano nowy model samochodu.",
            "Chociaż nie jestem j{u}ż przedszkolakiem, to na mnie {ch}uchają i dm{u}chają.",
            "Troszczą się o mnie, kiedy jestem u nich.",
            "Chcą jak najwięcej czas{u} spędzić ze mną, gdy tat{u}ś i mam{u}sia m{u}szą wyjść z dom{u} i p{ó}jść do pracy.",
            "Bawią się ze mną, oglądają filmy i pokaz{u}ją mi ciekawe strony dla dzieci w Internecie.",
            "Są ze mnie d{u}mni, gdy w szkole dostanę sz{ó}stkę, a nawet czw{ó}rkę.",
            "Pamiętają o mnie nie tylko, gdy mam {u}rodziny czy imieniny.",
            "Zawsze szepną mi cz{u}łe sł{ó}wko.",
            "Wybaczą, kiedy się sp{ó}źniam na podwieczorek.",
            "Moi dziadkowie wytł{u}maczą mi r{ó}wnież zadanie, kt{ó}rego nie roz{u}miem, bo dla nich wszystko jest proste jak dr{u}t.",
            "Zabiorą mnie w podr{ó}ż dookoła świata i oprowadzą po zakamarkach wiedzy, bo są jak kompas, co wskaz{u}je drogę do cel{u}."        )
    ),
)
