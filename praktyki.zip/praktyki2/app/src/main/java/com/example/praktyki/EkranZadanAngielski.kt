package com.example.praktyki

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun EkranZadanAngielski(klasa: String, categoryId: String) {
    // Rozpoznawanie typu zadania
    val category = allVocabulary.find { it.id == categoryId }
    val verbCategory = if (category == null) allVerbs.find { it.id == categoryId } else null
    
    // Obsługa gramatyki
    val grammarOptions = when (categoryId) {
        "present_simple_options" -> GrammarTasks.presentSimpleOptions13
        "present_perfect_options" -> GrammarTasks.presentPerfectOptions46
        else -> null
    }
    val grammarFill = when (categoryId) {
        "present_simple_fill" -> GrammarTasks.presentSimpleFill13
        "present_continuous_fill" -> GrammarTasks.presentContinuousFill13
        "present_perfect_fill" -> GrammarTasks.presentPerfectFill46
        else -> null
    }


    val totalItems = when {
        category != null -> category.words.size
        verbCategory != null -> verbCategory.verbs.size
        grammarOptions != null -> grammarOptions.size
        grammarFill != null -> grammarFill.size
        else -> 0
    }

    if (totalItems == 0) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Nie znaleziono zadań dla tej kategorii.")
        }
        return
    }

    var currentIndex by rememberSaveable { mutableIntStateOf(0) }
    var userGuess by rememberSaveable { mutableStateOf("") }
    var infinitiveGuess by rememberSaveable { mutableStateOf("") }
    var pastSimpleGuess by rememberSaveable { mutableStateOf("") }
    var pastParticipleGuess by rememberSaveable { mutableStateOf("") }
    
    var feedback by rememberSaveable { mutableStateOf("") }
    var isCorrect by rememberSaveable { mutableStateOf<Boolean?>(null) }
    var score by rememberSaveable { mutableIntStateOf(0) }
    var isFinished by rememberSaveable { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(scrollState),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (!isFinished) {
            val title = when {
                category != null -> "Słówka: ${category.name}"
                verbCategory != null -> "Czasowniki nieregularne"
                grammarOptions != null -> "Wybierz formę"
                grammarFill != null -> "Uzupełnij zdanie"
                else -> ""
            }

            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )

            // Wyświetlanie reguły gramatycznej
            val rule = when {
                categoryId.contains("present_perfect") -> 
                    "Present Perfect\npodmiot + have/has + III forma czasownika"
                categoryId.contains("present_simple") -> 
                    "Present Simple\npodmiot + czasownik w formie podstawowej *\nW trzeciej osobie liczby pojedynczej do czasownika dodajemy końcówkę -s"
                categoryId.contains("present_continuous") -> 
                    "Present Continuous\npodmiot + to be (am/is/are) + czasownik z końcówką -ing"
                else -> null
            }

            if (rule != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.padding(vertical = 16.dp).fillMaxWidth()
                ) {
                    Text(
                        text = rule,
                        textAlign = TextAlign.Center,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(12.dp).fillMaxWidth()
                    )
                }
            }
            
            Text(
                text = "Zadanie: ${currentIndex + 1} / $totalItems",
                modifier = Modifier.padding(bottom = 32.dp)
            )

            // WYŚWIETLANIE TREŚCI ZADANIA
            when {
                category != null -> {
                    val word = category.words[currentIndex]
                    Text(text = "Jak jest po angielsku:", fontSize = 18.sp)
                    Text(text = word.polish.uppercase(), fontSize = 32.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 16.dp))
                    OutlinedTextField(value = userGuess, onValueChange = { userGuess = it }, label = { Text("Wpisz po angielsku") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                }
                verbCategory != null -> {
                    val verb = verbCategory.verbs[currentIndex]
                    Text(text = "Formy czasownika:", fontSize = 18.sp)
                    Text(text = verb.polish.uppercase(), fontSize = 32.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 16.dp))
                    OutlinedTextField(value = infinitiveGuess, onValueChange = { infinitiveGuess = it }, label = { Text("Infinitive") }, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), singleLine = true)
                    OutlinedTextField(value = pastSimpleGuess, onValueChange = { pastSimpleGuess = it }, label = { Text("Past Simple") }, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), singleLine = true)
                    if (verb.pastParticiple.isNotEmpty()) {
                        OutlinedTextField(value = pastParticipleGuess, onValueChange = { pastParticipleGuess = it }, label = { Text("Past Participle") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    }
                }
                grammarOptions != null -> {
                    val task = grammarOptions[currentIndex]
                    Text(text = "${task.sentenceBefore} [.....] ${task.sentenceAfter}", fontSize = 22.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(bottom = 24.dp))
                    task.options.forEach { option ->
                        Button(
                            onClick = {
                                userGuess = option
                                val correct = option == task.correctOption
                                isCorrect = correct
                                if (correct) { score++; feedback = "Brawo!" } else { feedback = "Błąd! Poprawnie: ${task.correctOption}" }
                            },
                            enabled = isCorrect == null,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isCorrect != null && option == task.correctOption) Color(0xFF2E7D32) 
                                                else if (isCorrect == false && option == userGuess) Color(0xFFC62828)
                                                else MaterialTheme.colorScheme.secondary
                            )
                        ) {
                            Text(option)
                        }
                    }
                }
                grammarFill != null -> {
                    val task = grammarFill[currentIndex]
                    Text(text = "Użyj: ${task.verb}", color = Color.Red, fontSize = 26.sp)
                    Text(text = "${task.sentenceBefore} [.....] ${task.sentenceAfter}", fontSize = 22.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(vertical = 16.dp))
                    OutlinedTextField(value = userGuess, onValueChange = { userGuess = it }, label = { Text("Wpisz formę") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // PRZYCISK SPRAWDŹ / NASTĘPNE
            if (isCorrect == null) {
                // Pokazuj przycisk sprawdź tylko dla zadań tekstowych (nie dla wyboru opcji)
                if (grammarOptions == null) {
                    Button(
                        onClick = {
                            val correct = when {
                                category != null -> userGuess.trim().lowercase() == category.words[currentIndex].english.lowercase()
                                verbCategory != null -> {
                                    val v = verbCategory.verbs[currentIndex]
                                    infinitiveGuess.trim().lowercase() == v.infinitive.lowercase() && 
                                    pastSimpleGuess.trim().lowercase() == v.pastSimple.lowercase() &&
                                    (v.pastParticiple.isEmpty() || pastParticipleGuess.trim().lowercase() == v.pastParticiple.lowercase())
                                }
                                grammarFill != null -> userGuess.trim().lowercase() == grammarFill[currentIndex].correctAnswer.lowercase()
                                else -> false
                            }
                            isCorrect = correct
                            if (correct) {
                                score++
                                feedback = "Świetnie!"
                            } else {
                                feedback = when {
                                    category != null -> "Poprawnie: ${category.words[currentIndex].english}"
                                    verbCategory != null -> "Poprawnie: ${verbCategory.verbs[currentIndex].infinitive} - ${verbCategory.verbs[currentIndex].pastSimple}"
                                    grammarFill != null -> "Poprawnie: ${grammarFill[currentIndex].correctAnswer}"
                                    else -> "Błąd!"
                                }
                            }
                        },
                        enabled = userGuess.isNotEmpty() || infinitiveGuess.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth().height(56.dp)
                    ) {
                        Text("SPRAWDŹ")
                    }
                }
            } else {
                Text(text = feedback, color = if (isCorrect == true) Color(0xFF2E7D32) else Color(0xFFC62828), fontWeight = FontWeight.Bold, fontSize = 24.sp, modifier = Modifier.padding(bottom = 16.dp))
                Button(
                    onClick = {
                        if (currentIndex < totalItems - 1) {
                            currentIndex++; userGuess = ""; infinitiveGuess = ""; pastSimpleGuess = ""; pastParticipleGuess = ""; isCorrect = null; feedback = ""
                        } else { isFinished = true }
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (isCorrect == true) Color(0xFF2E7D32) else Color(0xFFC62828))
                ) {
                    Text(if (currentIndex < totalItems - 1) "NASTĘPNE" else "WYNIK")
                }
            }
        } else {
            // EKRAN KOŃCOWY
            Text("KONIEC!", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black)
            Text("Twój wynik:", fontSize = 24.sp, modifier = Modifier.padding(top = 16.dp))
            Text("$score / $totalItems", fontSize = 64.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(32.dp))
            Button(onClick = { currentIndex = 0; userGuess = ""; infinitiveGuess = ""; pastSimpleGuess = ""; pastParticipleGuess = ""; isCorrect = null; feedback = ""; score = 0; isFinished = false }, modifier = Modifier.fillMaxWidth().height(56.dp)) {
                Text("ZAGRAJ PONOWNIE")
            }
        }
    }
}
