package com.example.praktyki

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.*
import com.example.praktyki.ui.theme.PraktykiTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PraktykiTheme {
                // Główny kompozyt aplikacji
                Aplikacja()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Aplikacja() {
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            WysuwaneMenu(onNavigate = { route ->
                navController.navigate(route)
                scope.launch { drawerState.close() }
            })
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Aplikacja Edukacyjna") },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(imageVector = Icons.Default.Menu, contentDescription = "Menu")
                        }
                    }
                )
            }
        ) {
            NavHost(
                navController = navController,
                startDestination = "strona_glowna",
                modifier = Modifier.padding(it)
            ) {
                composable("strona_glowna") {
                    StronaGlowna(onNavigate = { route -> navController.navigate(route) })
                }
                composable("przedmiot/{subject}") { backStackEntry ->
                    val subject = backStackEntry.arguments?.getString("subject") ?: ""
                    EkranPrzedmiotu(subject = subject, onNavigate = { route -> navController.navigate(route) })
                }
                composable("klasa/{klasa}") { backStackEntry ->
                    val klasa = backStackEntry.arguments?.getString("klasa") ?: ""
                    EkranKlasy(klasa = klasa, onNavigate = { route -> navController.navigate(route) })
                }
                composable("dyktando") {
                    Dyktando()
                }
                composable("profil") {
                    EkranProfilu()
                }
            }
        }
    }
}
