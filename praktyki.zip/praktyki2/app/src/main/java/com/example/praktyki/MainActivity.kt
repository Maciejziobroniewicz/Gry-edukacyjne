package com.example.praktyki

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*
import com.example.praktyki.ui.theme.PraktykiTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PraktykiTheme {
                Aplikacja()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Aplikacja() {
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val canPop = currentRoute != "strona_glowna" && navController.previousBackStackEntry != null

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            WysuwaneMenu(onNavigate = { route ->
                navController.navigate(route)
                scope.launch { drawerState.close() }
            })
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { 
                        Text("Aplikacja Edukacyjna") 
                    },
                    navigationIcon = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(start = 4.dp)
                        ) {
                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                Icon(imageVector = Icons.Default.Menu, contentDescription = "Menu")
                            }
                            if (canPop) {
                                IconButton(onClick = { navController.popBackStack() }) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowBack, 
                                        contentDescription = "Cofnij"
                                    )
                                }
                            }
                        }
                    }
                )
            }
        ) {
            NavHost(
                navController = navController,
                startDestination = "strona_glowna",
                modifier = Modifier.padding(it)
            ) {
                composable("strona_glowna") {
                    StronaGlowna(onNavigate = { route -> navController.navigate(route) })
                }
                composable("przedmiot/{subject}") { backStackEntry ->
                    val subject = backStackEntry.arguments?.getString("subject") ?: ""
                    EkranPrzedmiotu(subject = subject, onNavigate = { route -> navController.navigate(route) })
                }
                class NavTypes {
                    // Placeholder for potential custom nav types
                }
                composable("klasa/{subject}/{klasa}") { backStackEntry ->
                    val subject = backStackEntry.arguments?.getString("subject") ?: ""
                    val klasa = backStackEntry.arguments?.getString("klasa") ?: ""
                    EkranKlasy(subject = subject, klasa = klasa, onNavigate = { route -> navController.navigate(route) })
                }
                composable("wybor_slowek/{klasa}") { backStackEntry ->
                    val klasa = backStackEntry.arguments?.getString("klasa") ?: ""
                    EkranWyboruSlowek(klasa = klasa, onNavigate = { route -> navController.navigate(route) })
                }
                composable("wybor_czasy/{klasa}") { backStackEntry ->
                    val klasa = backStackEntry.arguments?.getString("klasa") ?: ""
                    EkranWyboruCzasy(klasa = klasa, onNavigate = { route -> navController.navigate(route) })
                }
                composable("wybor_zadan_czasy/{klasa}/{tense}") { backStackEntry ->
                    val klasa = backStackEntry.arguments?.getString("klasa") ?: ""
                    val tense = backStackEntry.arguments?.getString("tense") ?: ""
                    EkranWyboruZadanCzasy(klasa = klasa, tense = tense, onNavigate = { route -> navController.navigate(route) })
                }
                composable("wybor_kategorii_dyktanda/{klasa}") { backStackEntry ->
                    val klasa = backStackEntry.arguments?.getString("klasa") ?: ""
                    EkranWyboruKategoriiDyktanda(klasa = klasa, onNavigate = { route -> navController.navigate(route) })
                }
                composable("wybor_dyktanda/{klasa}/{category}") { backStackEntry ->
                    val klasa = backStackEntry.arguments?.getString("klasa") ?: ""
                    val category = backStackEntry.arguments?.getString("category") ?: ""
                    EkranWyboruDyktanda(klasa = klasa, category = category, onNavigate = { route -> navController.navigate(route) })
                }
                composable("wybor_samoglosek/{klasa}") { backStackEntry ->
                    val klasa = backStackEntry.arguments?.getString("klasa") ?: ""
                    EkranWyboruSamoglosek(klasa = klasa, onNavigate = { route -> navController.navigate(route) })
                }
                composable("zadania/polski/{klasa}/{category}") { backStackEntry ->
                    val category = backStackEntry.arguments?.getString("category") ?: ""
                    val klasa = backStackEntry.arguments?.getString("klasa") ?: ""
                    EkranZadanPolski(klasa = klasa, category = category)
                }
                composable("wybor_matematyka/{klasa}/{group}") { backStackEntry ->
                    val klasa = backStackEntry.arguments?.getString("klasa") ?: ""
                    val group = backStackEntry.arguments?.getString("group") ?: ""
                    EkranWyboruZadanMatematyka(klasa = klasa, group = group, onNavigate = { route -> navController.navigate(route) })
                }
                composable("dyktando/{id}") { backStackEntry ->
                    val id = backStackEntry.arguments?.getString("id") ?: ""
                    Dyktando(dictationId = id)
                }
                composable("zadania/angielski/{klasa}/{category}") { backStackEntry ->
                    val category = backStackEntry.arguments?.getString("category") ?: ""
                    val klasa = backStackEntry.arguments?.getString("klasa") ?: ""
                    EkranZadanAngielski(klasa = klasa, categoryId = category)
                }
                composable("zadania/matematyka/{klasa}/{category}") { backStackEntry ->
                    val category = backStackEntry.arguments?.getString("category") ?: ""
                    EkranZadanMatematyka(category = category)
                }
                composable("profil") {
                    EkranProfilu()
                }
            }
        }
    }
}
