package com.example.praktyki

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun EkranZadanPolski(klasa: String, category: String) {
    // Pobieramy dane z zewnętrznego obiektu PolishTasks (Refaktoryzacja)
    val sourceTasks = if (klasa == "1-3") PolishTasks.vowelWords13 else PolishTasks.vowelWords46
    
    val shuffledIndices = rememberSaveable {
        ArrayList((sourceTasks.indices).shuffled())
    }

    var currentIndex by rememberSaveable { mutableIntStateOf(0) }
    var userAnswer by rememberSaveable { mutableStateOf("") }
    var feedback by rememberSaveable { mutableStateOf("") }
    var isCorrect by rememberSaveable { mutableStateOf<Boolean?>(null) }
    var score by rememberSaveable { mutableIntStateOf(0) }
    var isFinished by rememberSaveable { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(scrollState),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (!isFinished) {
            val currentTask = sourceTasks[shuffledIndices[currentIndex]]

            Text(
                text = "Ile jest samogłosek?",
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.primary
            )

            Text(
                text = "Zadanie: ${currentIndex + 1} / ${sourceTasks.size}",
                modifier = Modifier.padding(vertical = 8.dp)
            )

            Text(text = "Wynik: $score", style = MaterialTheme.typography.bodyMedium)

            Spacer(modifier = Modifier.height(32.dp))

            Text(
                text = currentTask.word.uppercase(),
                fontSize = 48.sp,
                fontWeight = FontWeight.Black,
                modifier = Modifier.padding(bottom = 32.dp)
            )

            OutlinedTextField(
                value = userAnswer,
                onValueChange = { if (it.all { char -> char.isDigit() }) userAnswer = it },
                label = { Text("Wpisz liczbę") },
                modifier = Modifier.width(150.dp),
                singleLine = true,
                textStyle = LocalTextStyle.current.copy(fontSize = 24.sp, fontWeight = FontWeight.Bold)
            )

            Spacer(modifier = Modifier.height(24.dp))

            if (isCorrect == null) {
                Button(
                    onClick = {
                        if (userAnswer.toIntOrNull() == currentTask.vowelCount) {
                            isCorrect = true
                            feedback = "Brawo! Poprawnie."
                            score++
                        } else {
                            isCorrect = false
                            feedback = "Błąd! Poprawna liczba to ${currentTask.vowelCount}"
                        }
                    },
                    enabled = userAnswer.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth().height(56.dp)
                ) {
                    Text("SPRAWDŹ", fontSize = 18.sp)
                }
            } else {
                Text(
                    text = feedback,
                    color = if (isCorrect == true) Color(0xFF2E7D32) else Color(0xFFC62828),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 24.sp,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                Button(
                    onClick = {
                        if (currentIndex < sourceTasks.size - 1) {
                            currentIndex++
                            userAnswer = ""
                            isCorrect = null
                            feedback = ""
                        } else {
                            isFinished = true
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isCorrect == true) Color(0xFF2E7D32) else Color(0xFFC62828)
                    )
                ) {
                    Text(if (currentIndex < sourceTasks.size - 1) "NASTĘPNE SŁOWO" else "ZOBACZ WYNIK", fontSize = 18.sp)
                }
            }
        } else {
            Text("KONIEC!", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black)
            Text("Twój wynik:", fontSize = 24.sp, modifier = Modifier.padding(top = 16.dp))
            Text("$score / ${sourceTasks.size}", fontSize = 64.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
            
            Spacer(modifier = Modifier.height(32.dp))
            
            Button(
                onClick = {
                    shuffledIndices.clear()
                    shuffledIndices.addAll((sourceTasks.indices).shuffled())
                    currentIndex = 0
                    userAnswer = ""
                    isCorrect = null
                    feedback = ""
                    score = 0
                    isFinished = false
                },
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) {
                Text("ZAGRAJ JESZCZE RAZ", fontSize = 18.sp)
            }
        }
        Spacer(modifier = Modifier.height(100.dp))
    }
}
