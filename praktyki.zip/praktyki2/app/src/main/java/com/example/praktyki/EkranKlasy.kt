package com.example.praktyki

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun EkranKlasy(subject: String, klasa: String, onNavigate: (String) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val displaySubject = when(subject) {
            "polski" -> "Język polski"
            "angielski" -> "Język angielski"
            "matematyka" -> "Matematyka"
            else -> subject
        }

        Text(
            text = "Klasa $klasa - $displaySubject",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(vertical = 24.dp)
        )

        val kategorie = when(subject) {
            "polski" -> listOf(
                "Dyktanda" to "dyktando",
                "Samogłoski" to "samogloski"
            )
            "angielski" -> listOf(
                "Słówka" to "slowka",
                "Czasy" to "czasy",
                "Czasowniki nieregularne" to "czasowniki"
            )
            "matematyka" -> listOf(
                "Działania" to "dzialania",
                "Liczby rzymskie" to "rzymskie",
                "Porównywanie" to "porownywanie"
            )
            else -> listOf("Zadania" to "zadania")
        }

        kategorie.forEach { (label, slug) ->
            Button(
                onClick = { 
                    when {
                        subject == "polski" && slug == "dyktando" -> onNavigate("wybor_kategorii_dyktanda/$klasa")
                        subject == "polski" && slug == "samogloski" -> onNavigate("wybor_samoglosek/$klasa")
                        subject == "angielski" && slug == "slowka" -> onNavigate("wybor_slowek/$klasa")
                        subject == "angielski" && slug == "czasy" -> onNavigate("wybor_czasy/$klasa")
                        subject == "angielski" && slug == "czasowniki" -> onNavigate("zadania/angielski/$klasa/czasowniki_$klasa")
                        subject == "matematyka" -> onNavigate("wybor_matematyka/$klasa/$slug")
                        else -> onNavigate("zadania/$subject/$klasa/$slug")
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .height(64.dp),
                shape = MaterialTheme.shapes.medium
            ) {
                Text(label, fontSize = 20.sp)
            }
        }
    }
}
